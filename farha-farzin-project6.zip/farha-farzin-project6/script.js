/*
//----------------------------------------------------
TECH 276 Project #6: Code Re-Use Game
Author: Farzin Farha
Date: 10/29/2025
Description:
This script handles input and basic interactivity
for the Insect Emporium homepage. It collects user
input from form fields and displays results using
alert() for debugging and output.
//----------------------------------------------------
*/

//----------------------------------------------------
// Function: ProcessSubmitForm()
// Purpose: Capture user's favorite insect and number preference,
// then display that information using an alert().
//----------------------------------------------------

function ProcessSubmitForm() {
    //Get User's fav insect
    var favInsect = document.getElementById("texts").value;

    //Get users num of fav insects
    var numOfInsects = document.getElementById("num").value;

    //Display collected info
    alert("Your favorite insect " + favInsect + " and you like " + numOfInsects + " insects ");

}


//Displays hello world button
function HelloWorldButn() {
    alert("Hello World");
}