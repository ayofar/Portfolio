/*
TECH 276 Project #6: Code Re-Use Game
Author: Farzin Farha
Date: 10/29/2025
Description:
This script powers the Sale page for the Insect Emporium.
It defines a Product class and uses buttons to:
- Buy items (reducing stock and adding to total)
- Restock items when they sell out
- Update the onscreen stock display
This demonstrates code reuse, debugging with alert() / console.log(),
and inventory logic using objects and functions.
*/

//----------------------------------
// CLASS DEFINITION: Product
//----------------------------------

class Product {

    // Constructor:
    // Sets up an insect product with a name, starting stock, and price.

    constructor(name, stock, price) {
        this.name = name;
        this.stock = stock;
        this.price = price;
    }


    // Sell()
    // Purpose: Attempt to sell ONE unit of this product.
    // Returns true if successful, false if out of stock.

    Sell() {

        //If stock is greatr than 0 

        if (this.stock > 0) {
            //then we sell the item we have in stock
            this.stock--;
            //we return it as true
            return true;
        }

        else {

            //if we have no items as all then this will display
            alert("Sorry we are out of stock")
            return false;
        }
    }

    // Restock(amount)
    // Purpose: Add more units back into inventory.
    // Only restocks if the amount is greater than 0.

    Restock(amount) {

        //if amount we ha2ve left after selling in greater than 0 
        if (amount > 0) {
            //add more to stock to the shop so we meet quota
            this.stock += amount;
            //display the restocked amount
            alert("Restocked amount: " + amount);

        }
        //else display not much in stock 
        else {
            alert("Not much in stock");
        }

    }

}

//----------------------------------
// CREATE PRODUCT OBJECTS
// Three separate inventory items for the new market
//----------------------------------
const prod1 = new Product("Lady Bug", 40, 250);
const prod2 = new Product("Bee", 10, 400);
const prod3 = new Product("Cockroach", 80, 100);



let total = 0;

//----------------------------------
// BuyProduct(prod)
// Purpose: Called when the user clicks "Buy" on a product row.
// - Tries to Sell() the product
// - If successful, increases running total
// - Shows debugging info via alert() and console.log()
// - Updates on-screen stock
//----------------------------------
function BuyProduct(prod) {

    //if product sells then dislay name, price and how much is in stock now after buying product
    if (prod.Sell()) {
        total += prod.price;
        alert("The product name is " + prod.name + " ,the price is " + prod.price + ", and we have " + prod.stock + " left in stock. Total money spent so far " + total);
    }
    //else there is no products to sell
    else {
        console.log("There are no products to sell");
    }


}

//----------------------------------
// RestockProduct(prod)
// Purpose: Called when the user clicks "Restock" on a product row.
// - Only restocks if stock is 0
// - Calls the product's Restock() function
// - Updates on-screen stock
//----------------------------------


function RestockProduct(stk) {


    if (stk.stock === 0) {
        stk.Restock(10);
        alert("Back up in stock by 10");
    }

    else {
        alert("WE ARE NOT IN STOCK");
    }


}
