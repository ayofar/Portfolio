/*
    Project: TECH 276 Project #7 - Password Strength Checker
    Author: Farzin Farha
    Date: November 5, 2025
    File: script.js
    Description: Contains JavaScript functions for evaluating password strength and interactivity.
*/

/*
plan
1. watch what the user types in the password box
2. check the password strength
3. show feedback on page 
4. Add meter (optional)
*/

/**************************************************************************************/
//Global Variables Here
/**************************************************************************************/

const passwordInputData = document.getElementById("passwordInput");
const msgDisplay = document.getElementById("displays");
const str = document.getElementById("strength");
const fdbck = document.getElementById("feedbacktxt");
const mtr = document.getElementById("meterBit");


/**************************************************************************************/
// Function Name: Input Event Listener
// Parameters: None
// Return: None
// Description: Detects when user types in the password box and updates the display
//              by calling checkPasswordStrength() to evaluate password strength.
/**************************************************************************************/

passwordInputData.addEventListener("input", () => {

    const passwrd = passwordInputData.value;

    //Call the function to check the password strength
    const res = checkPasswordStrength(passwrd);

    //Update the meter value with the strength number
    mtr.value = res.strength;

    //Change colors and text based on strength score
    if (passwordInputData.value.length > 0) {
        msgDisplay.style.display = "block";
        fdbck.style.display = "block";
        mtr.style.display = "block";
    }
    else {
        msgDisplay.style.display = "none";
        fdbck.style.display = "none";
        mtr.style.display = "none";

    }

    if (res.strength <= 2) {
        str.innerHTML = "WEAK";
        passwordInputData.style.borderColor = "red";
        msgDisplay.style.color = "red";
        fdbck.style.color = "red";
        mtr.style.backgroundColor = "red";
        console.log("password is weak, try again LOL");
    }

    else if (res.strength <= 4) {
        str.innerHTML = "MODERATE";
        passwordInputData.style.borderColor = "#FFC300";
        msgDisplay.style.color = "#FFC300";
        fdbck.style.color = "#FFC300";
        mtr.style.backgroundColor = "#FFC300";
        console.log("password is moderate bro, wut you doin. Still, not too bad");
    }

    else {
        str.innerHTML = "STRONG";
        passwordInputData.style.borderColor = "green";
        msgDisplay.style.color = "green";
        fdbck.style.color = "green";
        mtr.style.backgroundColor = "green";
        console.log("AYOOOO THATS WHAT WE LIKE TO SEE. NICE STRONG PASSWORD");
        alert("You're password is very STRONG!! GOOD JOB");

    }

    //Display feedback messages separated by commas
    fdbck.textContent = res.feedback.join(",");


});

/**************************************************************************************/
// Function Name: checkPasswordStrength
// Parameters: password (string)
// Return: Object containing 'strength' (number) and 'feedback' (array)
// Description: Evaluates password strength by checking for length, case, numbers,
//              and special characters, and returns a numeric strength score.
/**************************************************************************************/
function checkPasswordStrength(password) {

    let strength = 0;
    let feedback = [];

    //Check minimum length
    if (password.length >= 8) {
        strength++;
    }
    else {
        feedback.push("Make password longer!!!");
    }

    //Check lowercase
    if (/[a-z]/.test(password)) {
        strength++;
    }
    else {
        feedback.push(" Include lowercase letters! ");
    }

    //Check uppercase
    if (/[A-Z]/.test(password)) {
        strength++;
    }
    else {
        feedback.push(" Include uppercase letters! ");
    }

    //Check numbers
    if (/[0-9]/.test(password)) {
        strength++;
    }
    else {
        feedback.push(" Include at least one number! ");
    }

    //Check special characters
    if (/[!@#$%^&*]/.test(password)) {
        strength++;
    }
    else {
        feedback.push("Include one special charcater! ");
    }

    return {
        strength, feedback
    }
}

/**************************************************************************************/
// Function Name: scroll
// Parameters: None
// Return: None
// Description: Controls when the navigation bar appears or hides based on the user's
//              scroll position on the page.
/**************************************************************************************/

window.onscroll = function () {
    scroll();
}


function scroll() {

    const navigation = document.getElementById("nav");

    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        navigation.style.top = "0";
    }
    else {
        navigation.style.top = "-50px";
    }
}
