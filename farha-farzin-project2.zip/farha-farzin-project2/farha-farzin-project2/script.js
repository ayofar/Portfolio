/*
Name: Farzin Farha
Class: TECH 276 Project #2
Date: September 28, 2025
Proj: Contains function to change text, color, and image attributes
*/

/*
Name: Farzin Farha
Param: None
Return: None
Desc: Changes the color of the main title when the button is cliked
*/

function changeColor() {
	document.getElementById("h1").style.color = "#f9a08d";
}

/*
Name: Farzin Farha
Param: None
Return: None
Desc: Displays an alert to the user and updates the heading text to say Importance of Pollination
*/

function changeTag() {
	alert("changed the title");
	document.getElementById('demo').innerHTML = "Importance of Pollination!!";
}

/*
Name: Farzin Farha
Param: None
Return: None
Desc: Logs a message to the console and changes the image source to display a different picture
*/

function changeAtt() {
	console.log("HELLOOOOOOOOOOO! The image has been updated! :))");
	document.getElementById('pollinationImage').src = "images/Poll.png";
}